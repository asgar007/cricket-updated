package com.example.match.model;

import com.example.match.util.Over;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "scoreboard")
public class Scoreboard {
    @Id
    private String scoreboardId;
    @Indexed
    private String trophyId;
    private String matchId;
    private String matchName;
    private String battingTeamName;
    private String bowlingTeamName;
    private int totalRuns;
    private int totalWickets;
    private int oversCompleted;
    private List<Over> overDetails;
//    private List<Player> playerDetails;
    private List<Player> batsmenDetails;
    private List<Player> bowlerDetails;
}
