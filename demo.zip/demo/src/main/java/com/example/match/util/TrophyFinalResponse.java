package com.example.match.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrophyFinalResponse {
    private String trophyWinner;
    private String trophyRunner;
    private List<FinalResponse> finalResponseList;
}
