package com.example.match.service;

import com.example.match.helper.StartMatchRequestHelper;
import com.example.match.model.*;
import com.example.match.repository.MatchRepository;
import com.example.match.util.FinalResponse;
import com.example.match.util.Over;
import com.example.match.util.TrophyFinalResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class MatchServiceImpl implements MatchService {

    private final MatchRepository matchRepository;

    private final PlayerService playerService;

    private final ScoreBoardService scoreBoardService;

    private final SeriesService seriesService;

    private final TeamService teamService;

    public Team makeTeam(String teamId, String teamName) {

        return Team.builder()
                .teamId(teamId).teamName(teamName)
                .players(playerService.getAllPlayers())
                .build();
    }

    private Optional<Team> getTeamFromSeriesGroupOne(String seriesId) {
        Series series = seriesService.findSeriesById(seriesId);
        List<String> groupOneIds = series.getGroupOneIds();
        //shuffle the list
        Collections.shuffle(groupOneIds);
        String teamOneId = groupOneIds.get(0);
        Optional.of(teamService.getTeamById(teamOneId));
        //take out Team from Team repo and return the Team
        return Optional.of(teamService.getTeamById(teamOneId));
    }

    public String startMatch(int overs) {

        //take out team from Series grp list;
        String seriesId = "10";
        Optional<Team> teamOne = getTeamFromSeriesGroupOne(seriesId);
        Optional<Team> teamTwo = getTeamFromSeriesGroupTwo(seriesId);

        Team team1 = makeTeam(teamOne.get().getTeamId(), teamOne.get().getTeamName());
        Team team2 = makeTeam(teamTwo.get().getTeamId(), teamTwo.get().getTeamName());


        Match match = Match.builder()
                .matchId("10")
                .battingTeam(team1)
                .bowlingTeam(team2)
                .totalOvers(overs)
                .build();

        //play match
        playMatch(overs, match.getMatchId(), team1);//batting team1 or first inning

        playMatch(overs, match.getMatchId(), team2);//batting team1 or second inning

        matchRepository.save(match);

        return match.getMatchId();
    }

    private Optional<Team> getTeamFromSeriesGroupTwo(String seriesId) {
        Series series = seriesService.findSeriesById(seriesId);
        List<String> groupTwoIds = series.getGroupTwoIds();
        //shuffle the list
        Collections.shuffle(groupTwoIds);
        String teamTwoId = groupTwoIds.get(0);
        //take out Team from Team repo and return the Team
        return Optional.of(teamService.getTeamById(teamTwoId));
    }

    private void playMatch(int overs, String matchId, Team team) {
        Scoreboard scoreboard = Scoreboard.builder()
                .matchId(matchId)
                .battingTeamName(team.getTeamName())
                .overDetails(new ArrayList<>())
                .batsmenDetails(new ArrayList<>())
                .oversCompleted(overs).build();
        //take out player from the team
        List<Player> players = team.getPlayers();
        int wickets = 0;
        int runs = 0;
        int currentPlayerNo = 1;
        int currentBatsmanRun = 0;
        //starting match
        Player player = Player.builder().playerId(players.get(currentPlayerNo).getPlayerId()).playerName(players.get(currentPlayerNo).getPlayerName()).teamId(team.getTeamId()).playerRole(players.get(currentPlayerNo).getPlayerRole()).build();
        for (int over = 1; over <= overs; over++) {
            int overRun = 0;
            Over tempOver = Over.builder().overNumber(over).overDetails(new ArrayList<>()).build();
            for (int ball = 1; ball <= 6; ball++) {
                int result = getRandomResult();
                if (result == 8) { // if wicket
                    //allocate random wicket type
                    String wicketType = allocateRandomWicket();
                    if (wickets == 10) break; // if All Out
                    tempOver.getOverDetails().add(wicketType);
                    scoreboard.setTotalWickets(wickets++);
                    //add outed players details to scoreboard
                    scoreboard.getBatsmenDetails().add(player);
                    /*NEXT PLAYER*/
                    // for next player
                    player = players.get(currentPlayerNo++);
                    currentBatsmanRun = 0;
                } else if (result == 9) { //if NO Ball
                    overRun = runs + 1;
                    tempOver.getOverDetails().add("NB");
                    scoreboard.setTotalRuns(runs + 1);
                    ball--; //give one more ball
                } else if (result == 10) { // if wide
                    overRun = runs + 1;
                    tempOver.getOverDetails().add("WD");
                    scoreboard.setTotalRuns(runs + 1);
                    ball--; //give one more ball
                } else {
                    runs += result;
                    overRun = runs;
                    tempOver.getOverDetails().add("" + result);
                    scoreboard.setTotalRuns(runs);
                    currentBatsmanRun += result;
                }
            }
            tempOver.setRunInOver(overRun);
            player.setTotalRuns(currentBatsmanRun);
            scoreboard.getOverDetails().add(tempOver);
        }
        scoreBoardService.createScoreBoard(scoreboard);
    }


    private String allocateRandomWicket() {
        int[] outcomes = {12, 13, 14, 15}; // bowled=12, runout=13, catch=14, lbw=15,
        int randomIndex = new Random().nextInt(outcomes.length);
        if (outcomes[randomIndex] == 12) return "Bowled";
        else if (outcomes[randomIndex] == 13) return "runout";
        else if (outcomes[randomIndex] == 14) return "catch";
        else return "lbw";
    }

    private int getRandomResult() {
        int[] outcomes = {0, 1, 2, 3, 4, 6, 0, 1, 2, 3, 4, 6, 8, 9, 10}; // 8= Wicket, 9=No ball, 10=wide
        int randomIndex = new Random().nextInt(outcomes.length);
        return outcomes[randomIndex];
    }

    public FinalResponse getMatchDetails(String matchId) {
        List<Scoreboard> scoreboards = scoreBoardService.findByMatchId(matchId);
        Optional<Scoreboard> winnerScoreboard = scoreboards.stream()
                .max(Comparator.comparingInt(Scoreboard::getTotalRuns));

        Optional<Scoreboard> runnerScoreboard = scoreboards.stream()
                .min(Comparator.comparingInt(Scoreboard::getTotalRuns));

        String winnerTeam = winnerScoreboard.map(Scoreboard::getBattingTeamName)
                .orElseThrow(() -> new IllegalStateException("No winner found for matchId: " + matchId));

        String runnerTeam = runnerScoreboard.map(Scoreboard::getBattingTeamName)
                .orElseThrow(() -> new IllegalStateException("No runner found for matchId: " + matchId));

        return FinalResponse.builder()
                .matchId(matchId)
                .winner(winnerTeam)
                .winnerRuns(winnerScoreboard.map(Scoreboard::getTotalRuns).orElse(0))
                .winnerWickets(winnerScoreboard.map(Scoreboard::getTotalWickets).orElse(0))
                .runner(runnerTeam)
                .runnerRuns(runnerScoreboard.map(Scoreboard::getTotalRuns).orElse(0))
                .runnerWickets(runnerScoreboard.map(Scoreboard::getTotalWickets).orElse(0))
                .build();
    }

    @Override
    public Scoreboard getScores(String battingTeamName) {
        return scoreBoardService.findByBattingTeamName(battingTeamName);
    }

    @Override
    public String startQuickMatch(StartMatchRequestHelper startMatchRequestHelper) {
        /*
         *StartMatchRequestHelper=> matchId, BattingTeamId, BowlingTeamId, overs;
         * */
        return startMatchWithTeamId(startMatchRequestHelper.getMatchId(), startMatchRequestHelper.getBattingTeamId(), startMatchRequestHelper.getBowlingTeamId(), startMatchRequestHelper.getOvers());
    }



    private void playMatchTest(int overs, String matchId, Team battingTeam, Team bowlingTeam){
        Scoreboard scoreboard = Scoreboard.builder()
                .trophyId("")
                .matchId(matchId)
                .battingTeamName(battingTeam.getTeamName())
                .overDetails(new ArrayList<>())
                .batsmenDetails(new ArrayList<>())
                .bowlerDetails(new ArrayList<>())
                .oversCompleted(overs).build();
        //take out player from the team
        List<Player> battingPlayers = battingTeam.getPlayers();
        List<Player> bowlingPlayers = bowlingTeam.getPlayers().stream().filter(player -> player.getPlayerRole().equals("bowler")).toList();
        int wickets = 0;
        int runs = 0;
        int currentBatsmanNo = 1;
        int currentBatsmanRun = 0;
        int currentBowlerNo = 0;
        int overRun = 0;
        int overWicket = 0;
        //start match
        //set player
        Player currentBatsman1 = Player.builder().playerId(battingPlayers.get(0).getPlayerId()).playerName(battingPlayers.get(0).getPlayerName()).teamId(battingTeam.getTeamId()).playerRole(battingPlayers.get(0).getPlayerRole()).build();
        Player currentBatsman2 = Player.builder().playerId(battingPlayers.get(1).getPlayerId()).playerName(battingPlayers.get(1).getPlayerName()).teamId(battingTeam.getTeamId()).playerRole(battingPlayers.get(1).getPlayerRole()).build();

        Player currentBowler;

        for (int over = 1; over <= overs; over++) {
            overRun = 0;
            overWicket = 0;
            //build fresh over with new bowler
            Over tempOver = Over.builder().overNumber(over).overDetails(new ArrayList<>()).build();
            if(currentBowlerNo >= bowlingPlayers.size()){
                currentBowlerNo = 0;
            }
            currentBowler = bowlingPlayers.get(currentBowlerNo++);
            System.err.println(overRun);
            for (int ball = 1; ball <= 6; ball++) {
                int result = getRandomResult();
                if (result == 8) { // if wicket

                    if (wickets == 10) break; // if All Out
                    wickets++;
                    overWicket++;
                    //allocate random wicket type
                    String wicketType = allocateRandomWicket();

                    tempOver.getOverDetails().add(wicketType);
                    // add score to scoreboard of outed i.e. current batsman
                    currentBatsman1.setTotalRuns(currentBatsmanRun);
                    // wickets to bowler score
                    currentBowler.setTotalWickets(currentBowler.getTotalWickets() + 1);
                    scoreboard.getBatsmenDetails().add(currentBatsman1);
                    currentBatsmanRun = 0;
                    //set next batsman
                    currentBatsman1 = battingPlayers.get(++currentBatsmanNo);
                }else if (result == 9) { //if NO Ball
                    overRun = overRun + 1;
                    tempOver.getOverDetails().add("NB");
                    ball--; //give one more ball
                } else if (result == 10) { // if wide
                    overRun = overRun + 1;
                    tempOver.getOverDetails().add("WD");
                    ball--; //give one more ball
                }else {
                    runs += result;
                    tempOver.getOverDetails().add("" + result);
                    overRun += result;
                    currentBatsmanRun += result;
                }
            }

            //swap current batsman
            Player temp = currentBatsman1;
            currentBatsman1 = currentBatsman2;
            currentBatsman2 = temp;

            //add details of bowler every over
            currentBowler.setTotalRuns(overRun);
            // add unique bowlers
            if(!scoreboard.getBowlerDetails().contains(currentBowler)){
                scoreboard.getBowlerDetails().add(currentBowler);
            }
            tempOver.setRunInOver(overRun);
            tempOver.setWicketInOver(overWicket);
            scoreboard.getOverDetails().add(tempOver);
            scoreboard.setTotalRuns(runs);
            scoreboard.setTotalWickets(wickets);
        }
        scoreBoardService.createScoreBoard(scoreboard);
    }

    @Override
    public String startMatchWithTeamId(String matchId, String battingTeamId, String bowlingTeamId,  int overs) {
        String seriesId = "1";
        String firstInningTeamName = "Ind";
        String secondInningTeamName = "Aus";
        Team firstInningTeam = makeTeamWithTeamId(battingTeamId, firstInningTeamName);
        Team secondInningTeam = makeTeamWithTeamId(bowlingTeamId, secondInningTeamName);

        Match match = Match.builder()
                .matchId(matchId)
                .battingTeam(firstInningTeam)
                .bowlingTeam(secondInningTeam)
                .totalOvers(overs)
                .build();

        //play match
        playMatchTest(overs, matchId, firstInningTeam, secondInningTeam);//batting team1 or first inning

        playMatchTest(overs, matchId, secondInningTeam,firstInningTeam);//batting team1 or second inning

        matchRepository.save(match);

        return match.getMatchId();
    }
    @Override
    public String startMatchWithTeamIdForTrophy(String tropyId, String matchId, String battingTeamId, String bowlingTeamId,  int overs) {
        String seriesId = "1";
        String firstInningTeamName = "Ind";
        String secondInningTeamName = "Aus";
        Team firstInningTeam = makeTeamWithTeamId(battingTeamId, firstInningTeamName);
        Team secondInningTeam = makeTeamWithTeamId(bowlingTeamId, secondInningTeamName);

        Match match = Match.builder()
                .matchId(matchId)
                .battingTeam(firstInningTeam)
                .bowlingTeam(secondInningTeam)
                .totalOvers(overs)
                .build();

        //play match
        playMatchTestForTrophy(tropyId, overs, match.getMatchId(), firstInningTeam, secondInningTeam);//batting team1 or first inning

        playMatchTestForTrophy(tropyId, overs, match.getMatchId(), secondInningTeam,firstInningTeam);//batting team1 or second inning

        matchRepository.save(match);

        return match.getMatchId();
    }

    private void playMatchTestForTrophy(String trophyId, int overs, String matchId, Team battingTeam, Team bowlingTeam){
        Scoreboard scoreboard = Scoreboard.builder()
                .trophyId(trophyId)
                .matchId(matchId)
                .battingTeamName(battingTeam.getTeamName())
                .overDetails(new ArrayList<>())
                .batsmenDetails(new ArrayList<>())
                .bowlerDetails(new ArrayList<>())
                .oversCompleted(overs).build();
        //take out player from the team
        List<Player> battingPlayers = battingTeam.getPlayers();
        List<Player> bowlingPlayers = bowlingTeam.getPlayers().stream().filter(player -> player.getPlayerRole().equals("bowler")).toList();
        int wickets = 0;
        int runs = 0;
        int currentBatsmanNo = 1;
        int currentBatsmanRun = 0;
        int currentBowlerNo = 0;
        int overRun = 0;
        int overWicket = 0;
        //start match
        //set player
        Player currentBatsman1 = Player.builder().playerId(battingPlayers.get(0).getPlayerId()).playerName(battingPlayers.get(0).getPlayerName()).teamId(battingTeam.getTeamId()).playerRole(battingPlayers.get(0).getPlayerRole()).build();
        Player currentBatsman2 = Player.builder().playerId(battingPlayers.get(1).getPlayerId()).playerName(battingPlayers.get(1).getPlayerName()).teamId(battingTeam.getTeamId()).playerRole(battingPlayers.get(1).getPlayerRole()).build();

        Player currentBowler;

        for (int over = 1; over <= overs; over++) {
            overRun = 0;
            overWicket = 0;
            //build fresh over with new bowler
            Over tempOver = Over.builder().overNumber(over).overDetails(new ArrayList<>()).build();
            if(currentBowlerNo >= bowlingPlayers.size()){
                currentBowlerNo = 0;
            }
            currentBowler = bowlingPlayers.get(currentBowlerNo++);
            System.err.println(overRun);
            for (int ball = 1; ball <= 6; ball++) {
                int result = getRandomResult();
                if (result == 8) { // if wicket

                    if (wickets == 10) break; // if All Out
                    wickets++;
                    overWicket++;
                    //allocate random wicket type
                    String wicketType = allocateRandomWicket();

                    tempOver.getOverDetails().add(wicketType);
                    // add score to scoreboard of outed i.e. current batsman
                    currentBatsman1.setTotalRuns(currentBatsmanRun);
                    // wickets to bowler score
                    currentBowler.setTotalWickets(currentBowler.getTotalWickets() + 1);
                    scoreboard.getBatsmenDetails().add(currentBatsman1);
                    currentBatsmanRun = 0;
                    //set next batsman
                    currentBatsman1 = battingPlayers.get(++currentBatsmanNo);
                }else if (result == 9) { //if NO Ball
                    overRun = overRun + 1;
                    tempOver.getOverDetails().add("NB");
                    ball--; //give one more ball
                } else if (result == 10) { // if wide
                    overRun = overRun + 1;
                    tempOver.getOverDetails().add("WD");
                    ball--; //give one more ball
                }else {
                    runs += result;
                    tempOver.getOverDetails().add("" + result);
                    overRun += result;
                    currentBatsmanRun += result;
                }
            }

            //swap current batsman
            Player temp = currentBatsman1;
            currentBatsman1 = currentBatsman2;
            currentBatsman2 = temp;

            //add details of bowler every over
            currentBowler.setTotalRuns(overRun);
            // add unique bowlers
            if(!scoreboard.getBowlerDetails().contains(currentBowler)){
                scoreboard.getBowlerDetails().add(currentBowler);
            }
            tempOver.setRunInOver(overRun);
            tempOver.setWicketInOver(overWicket);
            scoreboard.getOverDetails().add(tempOver);
            scoreboard.setTotalRuns(runs);
            scoreboard.setTotalWickets(wickets);
        }
        scoreBoardService.createScoreBoard(scoreboard);
    }
    @Override
    public TrophyFinalResponse getMatchDetailsForTrophy(String trophyId) {
        //find all scoreboard having this trophyId
        List<Scoreboard> scoreboards = scoreBoardService.findByTrophyId(trophyId);
        //filter out matchId;
        List<String> matchIds = scoreboards.stream().map(Scoreboard::getMatchId).distinct().toList();
        //now find the individual teams data
        List<FinalResponse> finalResponseList = new ArrayList<>();

        for(String matchId: matchIds){
            finalResponseList.add(getMatchDetails(matchId));
        }

        Map<String, Long> frequencyMap = finalResponseList.stream()
                .map(FinalResponse::getWinner)
                .collect(Collectors.groupingBy(s -> s, Collectors.counting()));

        String winner = frequencyMap.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);

        String runner = frequencyMap.entrySet().stream()
                .min(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);

        return TrophyFinalResponse.builder().trophyWinner(winner).trophyRunner(runner).finalResponseList(finalResponseList).build();
    }

    private Team makeTeamWithTeamId(String teamId, String teamName) {
        return Team.builder().teamId(teamId)
                .teamName(teamName)
                .players(playerService.getAllPlayers().stream().filter(player -> player.getTeamId().equals(teamId)).collect(Collectors.toList()))
                .build();
    }

}
