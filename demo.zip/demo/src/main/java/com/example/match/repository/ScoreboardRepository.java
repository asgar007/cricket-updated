package com.example.match.repository;


import com.example.match.model.Scoreboard;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface ScoreboardRepository extends MongoRepository<Scoreboard, String> {
    List<Scoreboard> findByMatchId(String matchId);

    Optional<Scoreboard> findByBattingTeamName(String battingTeamName);

    List<Scoreboard> findByTrophyId(String trophyId);
}
