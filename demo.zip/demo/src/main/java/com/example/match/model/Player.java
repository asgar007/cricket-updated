package com.example.match.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "player")
public class Player {
    @Id
    private String playerId;
    private String teamId;
    private String playerName;
    private String playerRole;
    private int totalRuns;
    private int totalWickets;
}
