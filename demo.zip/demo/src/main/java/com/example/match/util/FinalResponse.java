package com.example.match.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FinalResponse {
    private String matchId;
    private String winner;
    private int winnerRuns;
    private int winnerWickets;

    private String runner;
    private int runnerRuns;
    private int runnerWickets;
}
