package com.example.match.service;

import com.example.match.dto.PlayerDTO;
import com.example.match.model.Player;
import com.example.match.model.Team;
import com.example.match.repository.PlayerRepository;
import com.example.match.repository.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PlayerServiceImpl implements PlayerService{
    private final PlayerRepository playerRepository;
    private final ModelMapper modelMapper;

    @Override
    public PlayerDTO createPlayer(PlayerDTO playerDTO) {
        Player save = playerRepository.save(modelMapper.map(playerDTO, Player.class));
        return modelMapper.map(save, PlayerDTO.class);
//        return modelMapper.map(playerRepository.save(modelMapper.map(playerDTO, Player.class)), PlayerDTO.class);
    }

    @Override
    public List<Player> getAllPlayers() {
        // Retrieve all players from the database
        return playerRepository.findAll();
    }

//    @Override
//    public Team createTeam(Team team) {
//        Team team1 = Team.builder().teamId(team.getTeamId()).teamName(team.getTeamName()).players(new ArrayList<>()).build();
//        List<Player> players = playerRepository.findAll();
//        players.forEach(player -> {
//            //add team Id to player
//            player.setTeamId(team.getTeamId());
//            team1.getPlayers().add(player);
//        });
//        return teamRepository.save(team1);
//    }
}

