package com.example.match.controller;

import com.example.match.helper.StartMatchRequestHelper;
import com.example.match.service.MatchService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/quicks")
@RequiredArgsConstructor
public class QuickMatchController {

    private final MatchService matchService;

    @PostMapping()
    public ResponseEntity<String> startQuickMatch(@RequestBody StartMatchRequestHelper startMatchRequestHelper) {
        String matchBetween = matchService.startQuickMatch(startMatchRequestHelper);
        return ResponseEntity.ok("Match started with ID: " + matchBetween);
    }
}
