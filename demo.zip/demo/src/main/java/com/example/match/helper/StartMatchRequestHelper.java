package com.example.match.helper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StartMatchRequestHelper {
    private String matchId;
    private String battingTeamId;
    private String bowlingTeamId;
    private int overs;
}
