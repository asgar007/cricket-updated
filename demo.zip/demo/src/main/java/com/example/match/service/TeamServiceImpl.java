package com.example.match.service;

import com.example.match.dto.TeamDTO;
import com.example.match.model.Player;
import com.example.match.model.Team;
import com.example.match.repository.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TeamServiceImpl implements TeamService{

    private final TeamRepository teamRepository;
    private final PlayerService playerService;

    private final ModelMapper modelMapper;
    @Override
    public String createTeam(TeamDTO teamDTO) {
//        Team team1 = Team.builder().teamId(team.getTeamId()).teamName(team.getTeamName()).players(new ArrayList<>()).build();
        Team team = modelMapper.map(teamDTO, Team.class);
        List<Player> players = playerService.getAllPlayers().subList(0,11);
        players.forEach(player -> {
            //add team Id to player
            if (team.getPlayers()==null) team.setPlayers(new ArrayList<>());
            player.setTeamId(team.getTeamId());
            team.getPlayers().add(player);
        });
        return Optional.of(teamRepository.save(team))
                .map(Team::getTeamId)
                .orElseThrow(() -> new RuntimeException("Failed to save team or got null teamId"));
    }

    @Override
    public Team getTeamById(String teamId) {
        return teamRepository.findById(teamId).orElseGet(Team::new);
    }
}
