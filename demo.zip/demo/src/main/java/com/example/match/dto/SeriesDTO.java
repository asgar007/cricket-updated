package com.example.match.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class SeriesDTO {
    private String seriesId;
    private String seriesName;
    private List<String> groupOneIds;
    private List<String> groupTwoIds;
}
