package com.example.match.service;

import com.example.match.model.Scoreboard;

import java.util.List;

public interface ScoreBoardService {

    Scoreboard createScoreBoard(Scoreboard scoreboard);
    List<Scoreboard> findByMatchId(String matchId);
    List<Scoreboard> findByTrophyId(String trophyId);
    Scoreboard findByBattingTeamName(String battingTeamName);
}
