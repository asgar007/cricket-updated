package com.example.match.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerDTO {
    private String playerId;
    private String teamId;
    private String playerName;
    private String playerRole;
    private int totalRuns;
    private int totalWickets;
}
