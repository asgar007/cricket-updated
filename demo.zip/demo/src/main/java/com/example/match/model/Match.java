package com.example.match.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "match")
public class Match {
    @Id
    private String matchId;
    private Team battingTeam;
    private Team bowlingTeam;
    private int totalOvers;
    private String winnerteamId;
    private String looserTeamId;
//    private List<Over> overs;
}
