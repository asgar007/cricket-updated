package com.example.match.dto;

import com.example.match.model.Team;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MatchDTO {
    private String matchId;
    private Team battingTeam;
    private Team bowlingTeam;
    private int totalOvers;
    private String winnerteamId;
    private String looserTeamId;
//    private List<Over> overs;
}
