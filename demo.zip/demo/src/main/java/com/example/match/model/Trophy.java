package com.example.match.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "trophies")
public class Trophy {
    @Id
    private String trophyId;
    private String teamAId;
    private String teamBId;
    private int noOfMatches;
    private int noOfOvers;
    private int teamAWins;
    private int teamBWins;
    private List<Scoreboard> scoreboardList;
}
