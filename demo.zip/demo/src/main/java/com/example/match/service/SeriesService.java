package com.example.match.service;

import com.example.match.model.Series;

public interface SeriesService {
    Series createSeries(Series series);
    Series findSeriesById(String seriesId);
}
