package com.example.match.controller;

import com.example.match.model.Scoreboard;
import com.example.match.service.MatchService;
import com.example.match.util.FinalResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/matches")
public class MatchController {

    @Autowired
    private MatchService matchService;

    @GetMapping("/start/{overs}")
    public ResponseEntity<String> startMatch(@PathVariable int overs) {
        String matchId = matchService.startMatch(overs);
        return ResponseEntity.ok("Match started with ID: " + matchId);
    }

    @GetMapping("/start/{matchId}/{battingTeamId}/{bowlingTeamId}/{overs}")
    public ResponseEntity<String> startMatchWithTeamIds(@PathVariable String matchId, @PathVariable String battingTeamId, @PathVariable String bowlingTeamId, @PathVariable int overs ) {
        String mId = matchService.startMatchWithTeamId(matchId, battingTeamId, bowlingTeamId, overs);
        return ResponseEntity.ok("Match started with ID: " + mId);
    }

    @GetMapping("/score/{battingTeamName}")
    public ResponseEntity<Scoreboard> scores(@PathVariable String battingTeamName){
        return ResponseEntity.ok(matchService.getScores(battingTeamName));
    }

    @GetMapping("/details/{matchId}")
    public ResponseEntity<FinalResponse> getMatchDetails(@PathVariable String matchId) {
        FinalResponse finalResponse = matchService.getMatchDetails(matchId);
        return ResponseEntity.ok(finalResponse);
    }

}
