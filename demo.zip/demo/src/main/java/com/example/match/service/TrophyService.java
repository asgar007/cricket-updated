package com.example.match.service;

import com.example.match.model.Trophy;
import com.example.match.util.FinalResponse;
import com.example.match.util.TrophyFinalResponse;

import java.util.List;

public interface TrophyService {
    Trophy createAndpPlayTrophy(Trophy trophy);
    TrophyFinalResponse getFinalResponse(String trophyId);
}
