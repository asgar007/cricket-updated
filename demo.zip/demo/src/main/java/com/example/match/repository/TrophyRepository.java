package com.example.match.repository;

import com.example.match.model.Trophy;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TrophyRepository extends MongoRepository<Trophy, String> {
}
