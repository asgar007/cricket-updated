package com.example.match.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Over {
    private int overNumber;
    private int runInOver;
    private int wicketInOver;
    private List<String> overDetails;
}


