package com.example.match.dto;

import com.example.match.model.Player;
import com.example.match.util.Over;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ScoreboardDTO {
    private String scoreboardId;
    private String matchId;
    private String matchName;
    private String battingTeamName;
    private String bowlingTeamName;
    private int totalRuns;
    private int totalWickets;
    private int oversCompleted;
    private List<Over> overDetails;
    private List<Player> playerDetails;
//    private List<Player> batsmenDetails;
//    private List<Player> bowlerDetails;
}
