package com.example.match.service;

import com.example.match.dto.PlayerDTO;
import com.example.match.model.Player;
import com.example.match.model.Team;

import java.util.List;

public interface PlayerService {

    PlayerDTO createPlayer(PlayerDTO playerDTO);
    List<Player> getAllPlayers();

}
