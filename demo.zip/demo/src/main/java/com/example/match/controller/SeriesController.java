package com.example.match.controller;

import com.example.match.model.Series;
import com.example.match.service.SeriesService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/series")
public class SeriesController {

    private final SeriesService seriesService;

    @PostMapping
    public Series createSeries(@RequestBody Series series){
        return seriesService.createSeries(series);
    }
}
