package com.example.match.controller;

import com.example.match.dto.TeamDTO;
import com.example.match.model.Team;
import com.example.match.service.TeamService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/teams")
@AllArgsConstructor
public class TeamController {

    private final TeamService teamService;
    @PostMapping
    public ResponseEntity<String> createTeam(@RequestBody TeamDTO teamDTO){
        return ResponseEntity.ok("Team Created: " + teamService.createTeam(teamDTO));
    }
}
