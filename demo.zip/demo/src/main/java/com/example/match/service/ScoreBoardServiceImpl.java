package com.example.match.service;

import com.example.match.model.Scoreboard;
import com.example.match.repository.ScoreboardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ScoreBoardServiceImpl implements ScoreBoardService{

    private final ScoreboardRepository scoreboardRepository;
    @Override
    public Scoreboard createScoreBoard(Scoreboard scoreboard) {
        return scoreboardRepository.save(scoreboard);
    }

    @Override
    public List<Scoreboard> findByMatchId(String matchId) {
        return scoreboardRepository.findByMatchId(matchId);
    }

    @Override
    public List<Scoreboard> findByTrophyId(String trophyId) {
        return scoreboardRepository.findByTrophyId(trophyId);
    }

    @Override
    public Scoreboard findByBattingTeamName(String battingTeamName) {
        return scoreboardRepository.findByBattingTeamName(battingTeamName).orElseGet(Scoreboard::new);
    }
}
