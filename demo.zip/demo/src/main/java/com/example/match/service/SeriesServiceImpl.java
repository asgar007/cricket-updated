package com.example.match.service;

import com.example.match.model.Series;
import com.example.match.model.Team;
import com.example.match.repository.SeriesRepository;
import com.example.match.repository.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SeriesServiceImpl implements SeriesService{

    private final SeriesRepository seriesRepository;
    private final TeamRepository teamRepository;

    @Override
    public Series createSeries(Series series) {
        //take out available teams and allocate to grp1 and grp2
        List<Team> teams = teamRepository.findAll();
        List<Team> grpOne = teams.subList(0,2);
        List<Team> grpTwo = teams.subList(2,4);
        Series series1 = Series.builder()
                .seriesId(series.getSeriesId())
                .seriesName(series.getSeriesName())
                .groupOneIds(new ArrayList<>())
                .groupTwoIds(new ArrayList<>())
                .build();
        grpOne.forEach(team -> series1.getGroupOneIds().add(team.getTeamId()));
        grpTwo.forEach(team -> series1.getGroupTwoIds().add(team.getTeamId()));
        return seriesRepository.save(series1);
    }

    @Override
    public Series findSeriesById(String seriesId) {
        return seriesRepository.findById(seriesId).orElseGet(Series::new);
    }
}
