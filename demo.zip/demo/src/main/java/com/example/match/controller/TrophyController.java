package com.example.match.controller;

import com.example.match.model.Trophy;
import com.example.match.service.TrophyService;
import com.example.match.util.FinalResponse;
import com.example.match.util.TrophyFinalResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trophies")
@RequiredArgsConstructor
public class TrophyController {

    private final TrophyService trophyService;

    @PostMapping
    public ResponseEntity<Trophy> createAndPlayTrophy(@RequestBody Trophy trophy){
        return ResponseEntity.ok(trophyService.createAndpPlayTrophy(trophy));
    }

    @GetMapping("/{trophyId}")
    public ResponseEntity<TrophyFinalResponse> getFinalResponse(@PathVariable String trophyId){
        return ResponseEntity.ok(trophyService.getFinalResponse(trophyId));
    }

}
