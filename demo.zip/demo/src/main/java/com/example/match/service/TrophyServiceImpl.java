package com.example.match.service;

import com.example.match.model.Scoreboard;
import com.example.match.model.Trophy;
import com.example.match.repository.TrophyRepository;
import com.example.match.util.FinalResponse;
import com.example.match.util.TrophyFinalResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TrophyServiceImpl implements TrophyService{

    private final TrophyRepository trophyRepository;
    private final MatchService matchService;
    private final ScoreBoardService scoreBoardService;
    @Override
    public Trophy createAndpPlayTrophy(Trophy trophy) {
        /*Creation Part*/
        Trophy buildTrophy = Trophy.builder().trophyId(trophy.getTrophyId())
                .teamAId(trophy.getTeamAId()).teamBId(trophy.getTeamBId())
                .noOfMatches(trophy.getNoOfMatches())
                .noOfOvers(trophy.getNoOfOvers())
                .teamAWins(0).teamBWins(0)
                .scoreboardList(new ArrayList<>())
                .build();
        /* play trophy part*/
        for (int i = 0; i < trophy.getNoOfMatches(); i++) {
            String msg = matchService.startMatchWithTeamIdForTrophy(trophy.getTrophyId(),""+i ,trophy.getTeamAId(), trophy.getTeamBId(), trophy.getNoOfOvers());
//            String msg = matchService.startMatchWithTeamId(""+i ,trophy.getTeamAId(), trophy.getTeamBId(), trophy.getNoOfOvers());

            System.out.println(msg);
        }
        //take out scoreBoard from DB and save to Trophy result
        List<Scoreboard> scoreboards = scoreBoardService.findByTrophyId(trophy.getTrophyId());
        buildTrophy.setScoreboardList(scoreboards);
        return trophyRepository.save(buildTrophy);
    }

    @Override
    public TrophyFinalResponse getFinalResponse(String trophyId) {
        return matchService.getMatchDetailsForTrophy(trophyId);
    }
}
