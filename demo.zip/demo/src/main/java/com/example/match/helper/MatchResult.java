package com.example.match.helper;

import com.example.match.model.Scoreboard;

public class MatchResult {
    private Scoreboard scoreboard;
}
