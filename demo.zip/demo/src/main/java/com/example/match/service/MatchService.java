package com.example.match.service;

import com.example.match.helper.StartMatchRequestHelper;
import com.example.match.model.Scoreboard;
import com.example.match.util.FinalResponse;
import com.example.match.util.TrophyFinalResponse;

public interface MatchService {
    String startMatch(int overs);
    String startMatchWithTeamId(String matchId, String battingTeamId, String bowlingTeamId,  int overs);
    String startMatchWithTeamIdForTrophy(String tropyId, String matchId, String battingTeamId, String bowlingTeamId,  int overs);
    TrophyFinalResponse getMatchDetailsForTrophy(String trophyId);
    FinalResponse getMatchDetails(String matchId);
    Scoreboard getScores(String battingTeamName);

    String startQuickMatch(StartMatchRequestHelper startMatchRequestHelper);
}
