package com.example.match.service;

import com.example.match.dto.TeamDTO;
import com.example.match.model.Team;

import java.util.Optional;

public interface TeamService {
    String createTeam(TeamDTO teamDTO);
    Team getTeamById(String teamId);
}
